 <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Designed by <a href="https://alimuange.wixsite.com/myself" target="_blank">Ali Cosmas Muange</a></span>
          </div>
        </div>
      </footer>