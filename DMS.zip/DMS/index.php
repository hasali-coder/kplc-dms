
<?php

error_reporting(0);
include('admin/include/dbconnection.php');

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<title>KPLC-DMS </title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/index.jpg">

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" 
    <div class="container">
      <a class="navbar-brand" href="index.php"> KPLC-Directory Management System</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
     <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="admin/">Admin Login
              <span class="sr-only">(current)</span>
            </a>
          </li>
     
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">
<form name="search" method="post" action="searchdata.php">
       <div class="card my-4">
          <h5 class="card-header">Search By Name / Staff Number</h5>
          <div class="card-body">
            <div class="input-group">
              <input type="text" class="form-control" name="searchdata" placeholder="Search for..." required="true">
              <span class="input-group-btn">
                <button class="btn btn-secondary" type="submit">Go!</button>
              </span>
            </div>
          </div>
        </div>
</form>

  
    <div class="row text-left">
<?php
$ret=mysqli_query($con,"select * from tbldirectory where (FullName like '$sdata%'|| StaffNo like '$sdata%' || Email like '$sdata%')  order by id desc limit 12 ");
$num=mysqli_num_rows($ret);
if($num>0){
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {

?>
      <div class="col-lg-4 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <h4 class="card-title" align="center"><?php  echo $row['FullName'];?></h4>
            <p ><b>Extension Number:</b> <?php  echo $row['MobileNumber'];?></p>
           
              
                  <p class="card-text"><b>Staff Number:</b> <?php echo $row['StaffNo'];?></p>
                   
          </div>
        </div>
      
      </div>
    <?php } }?>

      

    </div>
  </div>

  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">   <span>Developed by <a href="https://alimuange.wixsite.com/myself" target="_blank">Ali Cosmas Muange</a>2020</span></p>
    </div>
  </footer>

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
