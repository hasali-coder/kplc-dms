

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



--
-- Database: `dmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(11) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'cosmas muange', 'admin', 746126579, 'cmuange@kplc.co.ke', '21232f297a57a5a743894a0e4a801fc3', '2020-03-12 10:17:22'),
(2, 'cosmas muange', 'admin', 746126579, 'cmuange@kplc.co.ke', 'admin', '2020-03-12 10:17:49'),
(3, 'muange ', 'adminMuange', 796967842, 'muange@kplc.co.ke', '7b8304f7b43d3be04cc170cf6d5b409e', '2020-03-12 10:36:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbldirectory`
--

CREATE TABLE `tbldirectory` (
  `ID` int(10) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `Profession` varchar(120) DEFAULT NULL,
  `Email` varchar(120) NOT NULL,
  `MobileNumber` varchar(11) DEFAULT NULL,
  `Address` varchar(250) NOT NULL,
  `City` varchar(250) NOT NULL,
  `StaffNo` text NOT NULL,
  `Floor` text NOT NULL,
  `fname` varchar(110) NOT NULL,
  `lname` varchar(110) NOT NULL,
  `mname` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldirectory`
--

INSERT INTO `tbldirectory` (`ID`, `FullName`, `Profession`, `Email`, `MobileNumber`, `Address`, `City`, `StaffNo`, `Floor`, `fname`, `lname`, `mname`) VALUES
(2, 'mark nyaboswa', 'HR', 'marknyaboswa@kplc.co.ke', '71', 'nairobi north ', 'E-House', 'kpl41020', '401', 'mark', '', 'nyaboswa\r\n'),
(3, 'caleb achesa', 'ICT', 'cachesa@kplc.co.ke', '789520', 'nairobi central', 'stima plaza', 'kpl14520', '601', 'caleb', '', 'achesa'),
(4, 'caleb achesa', 'ICT', 'cachesa@kplc.co.ke', '452160', 'kisumu', 'kisumu', 'kpl25263', '1.37500000', 'caleb', 'achesa', 'achesa\r\n'),
(5, 'urbanus utubora', 'hr', 'utubor@kplc.co.ke', '852410', 'nairobi central', 'stima plaza', 'kpl41155', '2.50000000', '', '', ''),
(6, 'noel kiboi', 'finance', 'noelkiboi@kplc.co.ke', '74552', 'nairobi central', 'stima plaza', 'kpl22345', '101', '', '', ''),
(8, 'sarah nyokabi', 'ict', 'snyokabi@kplc.co.ke', '2235', 'nairobi central', 'stima plaza', 'kpl14010', '502', '', '', ''),
(9, 'hassan mohammed', 'finance', 'hassanmohammed@kplc.co.ke', '3520', 'coast', 'mombasa depo', 'kpl11125', '1402', '', '', ''),
(10, 'cosmas muange muasya', 'ICT', 'cmuange@kplc.co.ke', '2250', 'nairobi central', 'stima plaza', 'kpl29009', '502', '', '', ''),
(11, 'mwamburi mwakale', 'infrastructure', 'mwakale@kplc.co.ke', '2105', 'coast', 'voi', 'kpl22521', '101', '', '', ''),
(13, 'william wephughukulu', 'project management', 'williamweph@kplc.co.ke', '4120', 'western', 'kakamega', 'kpl41520', '801', '', '', ''),
(14, 'khadija mohammed', 'legal services', 'khadijamohammed@kplc.co.ke', '2140', 'nairobi central', 'stima plaza', 'kpl3250', '202', '', '', ''),
(15, 'jamal mwangesha mwakazi', 'ICT', 'jmwange@kplc.co.ke', '0712835012', 'nairobi central', 'stima plaza', 'att36843963', '502', '', '', ''),
(16, 'brian njiru', 'finance', 'bnjiru@kplc.co.ke', '2150', 'nairobi west', 'dagoretti', 'kpl44785', '401', '', '', ''),
(17, 'grace koki', 'ICT', 'grace@kplc.co.ke', '2510', 'nairobi', 'stima plaza', 'kpl22520', '502', '', '', ''),
(18, 'nina ogutu', 'infrastructure', 'ninaogutu@kplc.co.ke', '2251', 'coast', 'coast e-house', 'kpl00101', '101', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbldirectory`
--
ALTER TABLE `tbldirectory`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbldirectory`
--
ALTER TABLE `tbldirectory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
